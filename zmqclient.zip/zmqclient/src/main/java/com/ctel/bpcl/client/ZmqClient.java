package com.ctel.bpcl.client;
import java.io.IOException;
import java.net.InetAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.zeromq.ZMQ;

/**
 *
 * @author Amresh
 *         <p>
 *         ZMQ Client (Producer)
 *         </p>
 *
 */
@Service
public class ZmqClient {

    static Logger logger = LoggerFactory.getLogger(ZmqClient.class);

    public static String zmqClientRegister(InetAddress ipAddress, String mac, String computerName) throws IOException {
        ZMQ.Context context = ZMQ.context(1);

        /**
         * Socket to talk to server
         */
        @SuppressWarnings("deprecation")
        ZMQ.Socket requester = context.socket(ZMQ.REQ);

        /**
         * Connecting ZMQ Server
         */
        requester.connect("tcp://10.10.13.71:5555");

        /**
         * Preparing data to Send over the Network
         */
        String request = String.valueOf("{PingStatus: " + ipAddress.isReachable(1000) + ",IpAddress:" + ipAddress
                + ",ComputerName:" + computerName + ",MacId:" + mac + "}");
        logger.info("ZMQ CLIENT {} Sending CPU PING To the ZMQ Server {} " + request);

        /**
         * Sending Data to the ZMQ Server
         */
        requester.send(request.getBytes(), 0);

        /*
         * <p> If we need to get reply from server </p>
         *
         * for (int requestNbr = 0; requestNbr != 100; requestNbr++) { String request =
         * String.valueOf(hostData.isReachable(1000) + " FROM " + computerName );
         * System.out.println("Sending CPU PING:" + request);
         * requester.send(request.getBytes(), 0);
         *
         * byte[] reply = requester.recv(0); System.out.println("Received " + new
         * String(reply) + " " + requestNbr); }
         */
        requester.close();
        context.term();
        return "ZMQ Opreation done.";
       
    }// End of method
}// End of class

