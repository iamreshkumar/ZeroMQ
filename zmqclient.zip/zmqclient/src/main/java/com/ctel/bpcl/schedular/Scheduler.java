package com.ctel.bpcl.schedular;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ctel.bpcl.client.ZmqClient;

/**
 *
 * @author ctel
 *
 *         <p>
 *         Scheduler for Getting Data From MYSQL DB
 *         </p>
 */
@Component
public class Scheduler {

    Logger logger = LoggerFactory.getLogger(Scheduler.class);

    /**
     * <p>
     * Scheduled JOB -> It will automatically execute in 15 second.
     * </p>
     *
     * @throws IOException
     */
    @Scheduled(fixedDelay = 15000, initialDelay = 5000)
    public void fixedDelaySch() throws IOException {
        logger.info("ZMQ Client {} Schedular job Stared in 15 sec");

        InetAddress ip;
        ip = InetAddress.getLocalHost();
        NetworkInterface network = NetworkInterface.getByInetAddress(ip);
        byte[] mac = network.getHardwareAddress();

        StringBuilder computrtMacId = new StringBuilder();
        for (int i = 0; i < mac.length; i++) {
            computrtMacId.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
        }

        try {
            ZmqClient.zmqClientRegister(InetAddress.getLocalHost(), computrtMacId.toString(), ip.getHostName());
        } catch (Exception e) {
            logger.info("Schedular {} Something issue while connecting with ZMQ Client.");
            e.printStackTrace();
        }

    }
}